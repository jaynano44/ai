'''
sample_pac/__init__.py
sample_pac 패키지를 import 할 때 자동실행되는 파일입니다
'''
print("sample_pac 패키지를 로드했어요")

def test():
    print("sample_pac안의 test()입니다")