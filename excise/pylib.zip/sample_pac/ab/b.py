# sample_pac/ab/b.py (python sample_pac/ab/b.py)

def world():
    print('sample_pac.ab.b모듈의 world')
if __name__ == '__main__':
    world()